<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Footer</title>
    <!-- Tambahkan CSS atau bootstrap jika diperlukan -->
    <style>
        /* CSS tambahan */
    </style>
</head>
<body>

<footer style="border-top: 4px solid ;#90bd7d">
    <div class="container" style="padding-bottom: 50px;">
        <div class="row">
            <div class="col-md-4">
                <h3 style="color: #90bd7d;"><b>SHALFA.STORE</b></h3>
                <p>Jl. Sumatera Pekalongan</p>
                <p><i class="glyphicon glyphicon-earphone"></i> <a href="https://wa.me/083113426526" style="color: #000;">083113426526</a></p>
                <p><i class="glyphicon glyphicon-envelope"></i> <a href="mailto:shalfa.store@gmail.com" style="color: #000;">shalfa.store@gmail.com</a></p>
            </div>
            <div class="col-md-4">
                <h5><b>Menu</b></h5>
                <p><a href="#" style="color: #000;">Produk</a></p>
                <p><a href="#" style="color: #000;">Tentang kami</a></p>
                <p><a href="#" style="color: #000;">Hubungi Kami</a></p>
            </div>
            <div class="col-md-4">
                
            </div>
        </div>
    </div>

    <div class="copy" style="background-color: #90bd7d; padding: 5px; color: #fff; text-align: center;">
        <span>Copyright&copy; shalfa.store 2024</span>
    </div>
</footer>

</body>
</html>
