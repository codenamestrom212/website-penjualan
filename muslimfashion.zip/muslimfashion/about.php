<?php 
	include 'header.php';
?>

<style>
    .container {
        padding: 30px;
        background-color: #fff;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        margin-bottom: 20px;
    }

    h2 {
        text-align: center;
        padding-bottom: 10px;
        color: #333;
        background: linear-gradient(to right, #90bd7d, #f38b3c);
        display: inline-block;
        padding: 10px 20px;
        border-radius: 5px;
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }

    p {
        font-size: 18px;
        line-height: 1.6;
        text-align: justify;
        margin-bottom: 15px;
    }

    .icon {
        font-size: 24px;
        margin-right: 10px;
        color:#90bd7d;
    }
</style>

<div class="container">
<h2><b>Shalfa.store</b></h2>
<p>shalfa.store adalah pusat penjualan komputer yang berkomitmen menyediakan produk terbaik, dari perangkat keras, software, hingga aksesoris komputer lengkap.</p>
<p>Kami hadir untuk melayani Anda dengan pilihan produk berkualitas dari berbagai merek ternama dan layanan pelanggan yang siap membantu Anda memilih yang terbaik sesuai kebutuhan.</p>

<?php 
	include 'footer.php';
?>
