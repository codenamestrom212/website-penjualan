<?php 
include 'header.php';
$date = date('Y-m-d');

// Assuming $order_id, $customer_name, and $order_items are retrieved from the database
$order_id = $_POST['order_id'];
$customer_name = "Customer Name"; // Replace with actual customer name data

// Sample data (you should fetch this data from your database)
$order_items = [
    ["nama_produk" => "Longdress 2", "qty" => 2, "harga" => 50000, "subtotal" => 100000],
    ["nama_produk" => "Longdress Motif 1", "qty" => 1, "harga" => 75000, "subtotal" => 75000]
];
$total = 175000; // Calculate total based on order items

?>
<style type="text/css">
    @media print {
        .print {
            display: none;
        }
    }
</style>
<div class="container" style="padding-bottom: 300px;">
    <h2 class="text-center" style=" width: 100%; border-bottom: 4px solid gray; padding-bottom: 5px;"><b>Nota Pembelian</b></h2>

    <div class="row">
        <div class="col-md-6">
            <p><b>Order ID:</b> <?= $order_id; ?></p>
            <p><b>Tanggal:</b> <?= $date; ?></p>
            <p><b>Pelanggan:</b> <?= $customer_name; ?></p>
        </div>
        <div class="col-md-6 text-right print">
            <button onclick="window.print()" class="btn btn-primary"><i class="glyphicon glyphicon-print"></i> Cetak Nota</button>
        </div>
    </div>

    <table class="table table-striped">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Produk</th>
                <th>Qty</th>
                <th>Harga</th>
                <th>Subtotal</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $no = 1;
            foreach ($order_items as $item) {
                ?>
                <tr>
                    <td><?= $no; ?></td>
                    <td><?= $item['nama_produk']; ?></td>
                    <td><?= $item['qty']; ?></td>
                    <td>Rp.<?= number_format($item['harga']); ?></td>
                    <td>Rp.<?= number_format($item['subtotal']); ?></td>
                </tr>
                <?php 
                $no++;
            }
            ?>
            <tr>
                <td colspan="4" class="text-right"><b>Total</b></td>
                <td><b>Rp.<?= number_format($total); ?></b></td>
            </tr>
        </tbody>
    </table>

    <h4 class="text-center" style="font-weight: bold;">Terima kasih telah berbelanja di Shalfa.Store! Pesanan Anda sedang diproses dan akan segera dikirimkan ke alamat Anda.</h4>
</div>

<?php 
include 'footer.php';
?>
