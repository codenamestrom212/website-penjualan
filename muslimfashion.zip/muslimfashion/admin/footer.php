<footer style="background-color: gray;padding: 1px;" class="print">
	<h5 class="text-center">Copyright&copy; Shalfa.Store 2024</h5>
</footer>
</body>
</html>