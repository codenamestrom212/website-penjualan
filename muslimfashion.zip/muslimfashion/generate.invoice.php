<?php
require_once('tcpdf/tcpdf.php'); // Make sure TCPDF is installed and included
include 'config.php'; // Include your database connection

// Check if order_id is provided
if (!isset($_POST['order_id'])) {
    die("Order ID is missing.");
}

$order_id = $_POST['order_id'];

// Fetch order details based on order_id
$query = mysqli_query($conn, "SELECT o.order_id, o.order_date, c.customer_name, c.customer_address, p.product_name, p.price, oi.quantity FROM orders o 
JOIN order_items oi ON o.order_id = oi.order_id
JOIN products p ON oi.product_id = p.product_id
JOIN customers c ON o.customer_id = c.customer_id
WHERE o.order_id = '$order_id'");

if (mysqli_num_rows($query) == 0) {
    die("Order not found.");
}

// Prepare order data
$order = mysqli_fetch_assoc($query);
$customer_name = $order['customer_name'];
$customer_address = $order['customer_address'];
$order_date = $order['order_date'];

// Initialize TCPDF
$pdf = new TCPDF('P', PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetTitle('Invoice - Order #' . $order_id);

// Add a page
$pdf->AddPage();

// Invoice Title
$pdf->SetFont('helvetica', 'B', 16);
$pdf->Cell(0, 10, 'Invoice', 0, 1, 'C');
$pdf->Ln(5);

// Customer and Order Details
$pdf->SetFont('helvetica', '', 10);
$pdf->Cell(0, 10, 'Order ID: ' . $order_id, 0, 1);
$pdf->Cell(0, 10, 'Order Date: ' . $order_date, 0, 1);
$pdf->Cell(0, 10, 'Customer Name: ' . $customer_name, 0, 1);
$pdf->Cell(0, 10, 'Customer Address: ' . $customer_address, 0, 1);
$pdf->Ln(10);

// Table Header
$pdf->SetFont('helvetica', 'B', 10);
$html = '<table border="1" cellpadding="4">
            <tr>
                <th style="width: 10%;">No</th>
                <th style="width: 40%;">Product Name</th>
                <th style="width: 20%;">Price</th>
                <th style="width: 15%;">Quantity</th>
                <th style="width: 15%;">Subtotal</th>
            </tr>';

// Table Content
$pdf->SetFont('helvetica', '', 10);
$total = 0;
$no = 1;
mysqli_data_seek($query, 0); // Reset pointer to beginning of result set

while ($row = mysqli_fetch_assoc($query)) {
    $product_name = $row['product_name'];
    $price = $row['price'];
    $quantity = $row['quantity'];
    $subtotal = $price * $quantity;
    $total += $subtotal;

    $html .= '<tr>
                <td>' . $no++ . '</td>
                <td>' . $product_name . '</td>
                <td>Rp.' . number_format($price, 0, ',', '.') . '</td>
                <td>' . $quantity . '</td>
                <td>Rp.' . number_format($subtotal, 0, ',', '.') . '</td>
              </tr>';
}

$html .= '<tr>
            <td colspan="4" style="text-align: right;"><b>Total</b></td>
            <td>Rp.' . number_format($total, 0, ',', '.') . '</td>
          </tr>';
$html .= '</table>';

// Output HTML as PDF content
$pdf->writeHTML($html, true, false, true, false, '');

// Output the PDF as an inline document in the browser
$pdf->Output('invoice_' . $order_id . '.pdf', 'I');
?>
